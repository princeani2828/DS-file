#include<stdio.h>
void push();
void pop();
void display();
int size,d[20],top=-1;
int d[20];
int k;
int peek();
int i=0;
void main()
{
   int n;
     printf("Enter the input value of size");
      scanf("%d",&size);
  do
  {
  printf("Enter the function to be performed");
   printf("Enter \n1.Push\n2.Pop\n3.Display\n4.Exit");
  scanf("%d",&n);
      switch(n)
      { 
         case 1: push();
                 break;
        case 2: pop();
      	      break;
        case 3: display();
      	      break;
       //case 4:  peek();
      	      //break;
       //case 5: break;
      }
   }while(n!=4);
   int push(int size)
      {
       if(top==(size-1))
       {
          printf("The stack is overflow");
       }
      else
      {
      	printf("Enter the input value");
      	scanf("%d",&k);
      	top=top+1;
      	d[top]=k;
      	printf("The Element is inserted");
      }
      }
      int pop()
      
      {
      if(top==-1)
      {
      printf("The stack is underflow");
      }
      else
      {
        printf("The element deleted is %d",d[top]);
        top=top-1;
        }
        }
        int display()
        {
        if(top==-1)
        {
        printf("The stack is underflow\n");
        }
        else 
        {
        printf("Stack:\n");
        for(int i=0;i<=top;i++)
        {
        printf("%d\n",d[i]);
        }
        }
        }
        int peek()
        {
        if(top==-1)
        {
        printf("Stack underflow\n");
        }
        else
        {
        printf("The top most element is %d\n",d[top]);
        }
        }
        
        
        

        }
        
       
        
      
     
     
     
      
