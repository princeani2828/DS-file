#include<stdio.h>
 int count=0;

  int bs(int arr[20],int l,int h,int x)
  {
  int m;
 while(l<=h)
 {
  m=l+(h-l)/2;
  count+=2;
  
  if (arr[m] ==x){
  count+=2;
  return m;
  }
  if(arr[m]<x)
  {
  l=m+1;
  count+=2;
  }
  else{
  count++;
  h=m-1;
  }
  }
  return-1;
  count++;
  }
 
  int main(void)
  {
   int i,n,arr[20],x;
   printf("Enter the number of elements");
   scanf("%d",&n);
   count++;
   printf("Enter the elements");
   for(i=0;i<n;i++)
   {
    scanf("%d",&arr[i]);
    count+=2;
    }
    printf("Enter the element to search");
    scanf("%d",&x);
    count++;
    
    int result = bs(arr, 0, n - 1,x);
  if (result == -1)
  {
    printf("Not found");
    count++;
    }
    
  else{
    printf("Element is found at index %d", result);
    count++;
    }
  
  printf("\nTime complexity=%d",count);
  printf("\nSpace complexity=%d",20+4*n);
  return 0;
    }
    
