#include<stdio.h>
	int main()
	{
		int arr[10],i,n,j,count;
 		printf("Enter the number of Elements:");
		scanf("%d",&n);
		printf("Enter the value for Elements:");
		for(i=0;i<n;i++)
		{
		 scanf("%d",&arr[i]);\
		 count+2;
		 }count++;
		 
		 for(i=0;i<n-1;i++)
		 {
		   int min=i;
		   count+2;
		   
		   
		    for(j=i+1;j<n;j++)
		    {count++;
		     if(arr[j]< arr[min])
		     {
		      min=j;
		      count+2;
		      }
		      
		      
		      }count++;
		      if(min!=i)
		      {count++;
		      
		       int temp=arr[i];
		       arr[i]=arr[min];
		       arr[min]=temp;
		       
		       
		       }count++;
		       }count++;
		       printf("The sorted array is: ");
		       for(i=0;i<n;i++)
		       {count+2;
		       printf("%d,",arr[i]);
		       }count++;
		       
		       printf("\nThe time complexity is: %d",count);
		       printf("\nThe space complexity is:%d",20+4*n);
		       }
		       
		       
		  
		
		
