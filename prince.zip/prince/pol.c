#include<stdio.h>
struct pol
{
  int exp;
  int co;
  };
  int main()
  {
  
  int n,i;
  printf("Enter the number of terms:");
  scanf("%d",&n);
  struct pol p[n];
  for(i=0;i<n;i++)
  {
  printf("Enter the coefficent:");
  scanf("%d",&p[i].co);
  printf("Enter the Exponent:");
  scanf("%d",&p[i].exp);
  }
  for(i=0;i<n;i++)
  {
  printf("%dx^%d+",p[i].co,p[i].exp);
  }
  }
  
  
  
  
