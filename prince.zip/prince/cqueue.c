#include<stdio.h>
#define max 7
int queue[max];
int head=-1,rear=-1;
int enqueue(int data);
int dequeue();
int display();
void main()
{
       int op;
      printf("1.Enque\n2.Dequeue\n3.Display\n4.Exit\nEnter any number:");
      scanf("%d",&op);
  do
  {
    switch (op)
    {
       case 1:
          int data;
          printf("Enter element to be inserted:");
          scanf("%d",&data);
          enqueue(data);
          break;
        case 2:
          dequeue();
          break;
        case 3:
          display();
          break;
        case 4:
            break;
        default:
           printf("\nWrong Choice!\n");
           break;
    }
      printf("\n1.Enque\n2.Dequeue\n3.Display\n4.Exit\nEnter any number:");
      scanf("%d",&op);
  }while(op!=4);
}
int enqueue(int data)
{
    if (head==(rear+1)%max)
       printf("Queue is Full\n");
    else if(rear==-1 && head==-1)
    {
        rear=0,head=0;
        queue[rear]=data;
        printf("Element Inserted\n");
    }
    else
    {
        rear=(rear+1)%max;
        queue[rear]=data;
        printf("Element Inserted\n");
    }
}
int dequeue()
{
    if(head==-1 && rear==-1)
       printf("Queue is Empty!\n");
    else if(head==rear)
    {
       printf("Deleted Element is %d\n",queue[head]);
       head=-1,rear=-1;
    }
    else
    {
    	printf("Deleted element is %d\n",queue[head]);
    	head=(head+1)%max;
    }
}
int display()
{
    if(head==-1 && rear==-1)
         printf("Queue is empty!\n");
    else
    {
          int i=head;
          while(i!=rear)
          {
          	printf("%d,",queue[i]);
          	i=(i+1)%max;
          }
          printf("%d",queue[i]);
    }
}
