#include<stdio.h>
void main()
	{
	  int a,b,i,j,arr[20][20],n=0,spar[20][20];
	  printf("Enter the no of rows");
	  scanf("%d",&a);
	  printf("Enter the no of columns");
	  scanf("%d",&b);
	  printf("Enter the elements");
	  for(i=0;i<a;i++)
	  {
	   for(j=0;j<b;j++)
	   {
	     scanf("%d",&arr[i][j]);
	     if(arr[i][j]!=0)
	     n++;
	     }
	     }
	      for(i=0;i<a;i++)
	  {
	   for(j=0;j<b;j++)
	   {
	    printf("%d\t",arr[i][j]);
	    }
	    printf("\n");
	    }
	    printf("The resultant Matrix is:\n");
	    spar[0][0]=a;
	     spar[0][1]=b;
	     spar[0][2]=n;
	     int k=1;
	     for(i=0;i<a;i++)
	     {
	      for(j=0;j<b;j++)
	      {
	        if(arr[i][j]!=0)
	        {
	 spar[k][0]=i;
	 spar[k][1]=j;
	 spar[k][2]=arr[i][j];
	   k++;
	   }
	   }
	   }
	  for(i=0;i<n+1;i++)
	  {
	   for(j=0;j<3;j++)
	   {
	   
	 printf("%d\t",spar[i][j]);
	 }
	 printf("\n");
	 }
	 }
	        

