#include<stdio.h>
int rear=-1,head=-1;
int queue[10];
int enqueue(int data,int size);
int dequeue();
int display();
void main()
	{
	  int n,size;
	  printf("Enter the size of the queue: ");
	  scanf("%d",&size);
	  printf("1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\nEnter the Choice: ");
	  scanf("%d",&n);
	  do{
	     switch(n)
	     {
	      case 1:
	      {
	        int data;
	        printf("Enter the number to be inserted: ");
	        scanf("%d",&data);
	        enqueue(data,size);
	        }
	        break;
	        case 2:
	        {
	         dequeue();
	         }break;
	         case 3:
	         {
	          display();
	          }break;
	          case 4:
	          {
	           break;
	           }break;
	           default:
	           {printf("Invalid Entry");
	           }
	           break;
	           }
	           printf("1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\nEnter the Choice: ");
	  scanf("%d",&n);}while(n!=4);
	  }
	  
	  int enqueue(int data,int size)
	  {
	  if(rear==size-1)
	  {
	  printf("Queue is over flow\n");
	  }
	  else if(rear==-1&&head==-1)
	  {
	   rear=rear+1;
	   head=head+1;
	   queue[rear]=data;
	   printf("Element is inserted\n");
	   }
	   else
	   {
	   rear=rear+1;
	   queue[rear]=data;
	   printf("Element is inserted\n");
	   }
	   }
	   int dequeue()
	   {
	   if(rear==-1&&head==-1)
	   {
	     printf("Queue is over flow\n");
	     }
	     else if(head<=rear)
	     {
	      printf("Deleted Element is %d\n",queue[head]);
	      head=head+1;
	      }
	      else if(head>rear)
	      {
	      printf("No element to delete\n");
	      }
	      }
	      int display()
	      {
	       if(rear==-1&&head==-1)
	       {
	        printf("Queue underflow.\n");
	        }
	        else if(head>rear)
	        {
	         printf("Queue Underflow.\n");
	         }
	         else
	         {
	          for(int i=head;i<rear;i++)
	          {
	           printf("%d,",queue[i]);
	           }
	           printf("%d\n",queue[rear]);
	           }
	           }
	           
	           
	           
	      

	   
	  
	  
	           
	          
	         
 
