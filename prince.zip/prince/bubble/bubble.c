#include<stdio.h>
	int main()
	{
		int arr[10],i,n,j,count;
 		printf("Enter the number of Elements:");
		scanf("%d",&n);
		printf("Enter the value for Elements:");
		for(i=0;i<n;i++)
		{
		 scanf("%d",&arr[i]);\
		 count+2;
		 }count++;
		 for(i=0;i<n;i++)
		 {count++;
		  for(j=0;j<n-i-1;j++)
		  {count++;
		   if(arr[j]>arr[j+1])
		   {count++;
		    int temp=arr[j+1];
		    arr[j+1]=arr[j];
		    arr[j]=temp;
		    }count++;
		    }count++;
		    }
		    printf("The sorted array is: ");
		       for(i=0;i<n;i++)
		       {count+2;
		       printf("%d,",arr[i]);
		       }count++;
		       
		       
		       printf("\nThe time complexity is: %d",count);
		       printf("\nThe space complexity is:%d",20+4*n);
		       }
		       
		    
		    
		   
