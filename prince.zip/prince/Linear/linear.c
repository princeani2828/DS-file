#include<stdio.h>
int count=0;
void main()
{
  int i,n,s,j,k=0,a[20],index;
  printf("Enter the value for n");
  scanf("%d",&n);
  printf("Enter the value ");
  for(i=0;i<n;i++)
  {
   
   scanf("%d",&a[i]);
   count+=2;
   }
   {
    printf("Enter the element to be searched");
    scanf("%d",&s);
    }
    for(i=0;i<n;i++)
    {
     if(a[i]==s)
     {
     index=i;
     k++;
     count++;
     }
     }
     if(k==1)
     {
     printf("The value is found at %d",index);
     count++;
     }
     else
     {
     printf("The value is not found");
     }
     printf("\nTime complexity:%d\n",count);
     printf("\nspace complexity:%d\n",20+4*n);
     
    }
   
  
